import { SiteHeader } from "@/components/site-header"
import { Hero } from "@/components/hero"
import { Felicidade } from "@/components/felicidade"
import { Comandos } from "@/components/comandos"
import { Cuidados } from "@/components/cuidados"
import { SiteFooter } from "@/components/site-footer"

export default function Page() {
  return (
    <main className="min-h-screen">
      <SiteHeader />
      <Hero />
      <Felicidade />
      <Comandos />
      <Cuidados />
      <SiteFooter />
    </main>
  )
}

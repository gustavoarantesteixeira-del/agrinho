import { PawPrint } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-4 py-10 text-center">
        <div className="flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <PawPrint className="size-5" />
          </span>
          <span className="font-heading text-lg font-bold text-foreground">
            Cãorinho Feliz
          </span>
        </div>
        <p className="max-w-md text-pretty text-sm leading-relaxed text-muted-foreground">
          Dicas carinhosas para deixar seu cachorro mais feliz e bem cuidado.
          Em caso de dúvidas de saúde, consulte sempre um veterinário.
        </p>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Cãorinho Feliz. Feito com amor para quem
          ama cães.
        </p>
      </div>
    </footer>
  )
}

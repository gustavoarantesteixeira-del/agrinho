"use client"

import { useState } from "react"
import { PawPrint, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

const links = [
  { href: "#felicidade", label: "Felicidade" },
  { href: "#comandos", label: "Comandos" },
  { href: "#cuidados", label: "Cuidados" },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <a href="#topo" className="flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <PawPrint className="size-5" />
          </span>
          <span className="font-heading text-lg font-bold leading-tight text-foreground">
            Cãorinho Feliz
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="font-semibold text-muted-foreground transition-colors hover:text-primary"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <Button asChild className="hidden rounded-full font-semibold md:inline-flex">
          <a href="#comandos">Começar agora</a>
        </Button>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex size-10 items-center justify-center rounded-full text-foreground md:hidden"
          aria-label={open ? "Fechar menu" : "Abrir menu"}
        >
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>

      {open && (
        <nav className="flex flex-col gap-1 border-t border-border/60 px-4 py-3 md:hidden">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setOpen(false)}
              className="rounded-lg px-3 py-2 font-semibold text-foreground hover:bg-secondary"
            >
              {link.label}
            </a>
          ))}
          <Button asChild className="mt-2 rounded-full font-semibold">
            <a href="#comandos" onClick={() => setOpen(false)}>
              Começar agora
            </a>
          </Button>
        </nav>
      )}
    </header>
  )
}

import Image from "next/image"
import { Heart, GraduationCap } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section id="topo" className="relative overflow-hidden">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 md:grid-cols-2 md:py-20">
        <div className="flex flex-col gap-6">
          <span className="inline-flex w-fit items-center gap-2 rounded-full bg-secondary px-4 py-1.5 text-sm font-semibold text-secondary-foreground">
            <Heart className="size-4 text-primary" />
            Amor e cuidado todos os dias
          </span>
          <h1 className="text-balance font-heading text-4xl font-extrabold leading-[1.1] text-foreground md:text-6xl">
            Como cuidar do seu cachorro
          </h1>
          <p className="max-w-md text-pretty text-lg leading-relaxed text-muted-foreground">
            Descubra como deixar seu melhor amigo mais feliz e aprenda, passo a
            passo, a ensinar comandos com paciência, carinho e muita diversão.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild size="lg" className="rounded-full font-semibold">
              <a href="#felicidade">
                <Heart className="size-5" />
                Deixar mais feliz
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="secondary"
              className="rounded-full font-semibold"
            >
              <a href="#comandos">
                <GraduationCap className="size-5" />
                Ensinar comandos
              </a>
            </Button>
          </div>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-[2rem] border-4 border-card shadow-xl">
            <Image
              src="/images/hero-cachorro.png"
              alt="Cachorro golden retriever feliz correndo no gramado"
              width={720}
              height={720}
              priority
              className="h-full w-full object-cover"
            />
          </div>
          <div className="absolute -bottom-4 -left-4 hidden items-center gap-3 rounded-2xl bg-card px-5 py-4 shadow-lg sm:flex">
            <span className="flex size-10 items-center justify-center rounded-full bg-accent text-accent-foreground">
              <Heart className="size-5" />
            </span>
            <div className="leading-tight">
              <p className="font-heading font-bold text-foreground">+200 dicas</p>
              <p className="text-sm text-muted-foreground">para um cão feliz</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

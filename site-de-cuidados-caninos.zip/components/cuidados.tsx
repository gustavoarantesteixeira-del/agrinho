import { Stethoscope, Bath, Calendar, ShieldCheck } from "lucide-react"

const cuidados = [
  {
    icon: Stethoscope,
    titulo: "Visitas ao veterinário",
    texto:
      "Faça check-ups regulares, mantenha a vacinação e a vermifugação sempre em dia.",
  },
  {
    icon: Bath,
    titulo: "Higiene e banho",
    texto:
      "Escove o pelo com frequência, dê banhos na medida certa e cuide das unhas e dos dentes.",
  },
  {
    icon: ShieldCheck,
    titulo: "Prevenção de parasitas",
    texto:
      "Use produtos contra pulgas, carrapatos e vermes recomendados pelo seu veterinário.",
  },
  {
    icon: Calendar,
    titulo: "Rotina e carinho",
    texto:
      "Cães amam previsibilidade. Mantenha horários para comer, passear e descansar.",
  },
]

export function Cuidados() {
  return (
    <section id="cuidados" className="bg-secondary/40 py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wide text-primary">
            Saúde
          </span>
          <h2 className="mt-2 text-balance font-heading text-3xl font-extrabold text-foreground md:text-4xl">
            Cuidados essenciais do dia a dia
          </h2>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            Além de felicidade e treino, a saúde em dia garante uma vida longa e
            cheia de energia ao lado de quem você ama.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {cuidados.map((c) => (
            <div
              key={c.titulo}
              className="flex flex-col items-center rounded-2xl border border-border bg-card p-6 text-center shadow-sm"
            >
              <span className="flex size-12 items-center justify-center rounded-full bg-accent/40 text-accent-foreground">
                <c.icon className="size-6" />
              </span>
              <h3 className="mt-4 font-heading text-lg font-bold text-foreground">
                {c.titulo}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {c.texto}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

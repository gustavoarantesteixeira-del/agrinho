import Image from "next/image"
import { Activity, Bone, Users, Brain } from "lucide-react"

const dicas = [
  {
    icon: Activity,
    titulo: "Exercício diário",
    texto:
      "Passeios e brincadeiras gastam energia, evitam o tédio e mantêm o corpo saudável. Reserve um tempo todo dia.",
  },
  {
    icon: Brain,
    titulo: "Estímulo mental",
    texto:
      "Brinquedos interativos e jogos de cheirar deixam o cérebro do seu cão ativo e reduzem a ansiedade.",
  },
  {
    icon: Bone,
    titulo: "Alimentação correta",
    texto:
      "Ofereça ração de qualidade na quantidade certa e água sempre fresca. Petiscos saudáveis com moderação.",
  },
  {
    icon: Users,
    titulo: "Socialização",
    texto:
      "Conviver com pessoas e outros cães desde cedo torna seu pet mais confiante, calmo e sociável.",
  },
]

export function Felicidade() {
  return (
    <section id="felicidade" className="bg-secondary/40 py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="order-2 overflow-hidden rounded-[2rem] border-4 border-card shadow-lg md:order-1">
            <Image
              src="/images/cachorro-feliz.png"
              alt="Pessoa brincando carinhosamente com um cachorro feliz"
              width={640}
              height={520}
              className="h-full w-full object-cover"
            />
          </div>

          <div className="order-1 md:order-2">
            <span className="text-sm font-bold uppercase tracking-wide text-primary">
              Felicidade
            </span>
            <h2 className="mt-2 text-balance font-heading text-3xl font-extrabold text-foreground md:text-4xl">
              Como deixar seu cachorro mais feliz
            </h2>
            <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
              Um cão feliz é um cão saudável e equilibrado. Pequenos hábitos no
              dia a dia fazem toda a diferença no bem-estar do seu melhor amigo.
            </p>
          </div>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {dicas.map((dica) => (
            <div
              key={dica.titulo}
              className="rounded-2xl border border-border bg-card p-6 shadow-sm transition-transform hover:-translate-y-1"
            >
              <span className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <dica.icon className="size-6" />
              </span>
              <h3 className="mt-4 font-heading text-lg font-bold text-foreground">
                {dica.titulo}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {dica.texto}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

import Image from "next/image"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const comandos = [
  {
    nome: "Senta",
    passos:
      "Segure um petisco acima do focinho do cão e mova a mão para trás da cabeça dele. Naturalmente ele vai sentar. Assim que sentar, diga “Senta!”, elogie e dê o petisco.",
  },
  {
    nome: "Fica",
    passos:
      "Com o cão sentado, mostre a palma da mão e diga “Fica”. Dê um passo para trás. Se ele permanecer, volte e recompense. Aumente a distância e o tempo aos poucos.",
  },
  {
    nome: "Vem (chamada)",
    passos:
      "Abaixe-se, abra os braços e chame com voz alegre: “Vem!”. Quando ele chegar, comemore muito e recompense. Nunca use a chamada para brigar com ele.",
  },
  {
    nome: "Deita",
    passos:
      "Com o cão sentado, leve um petisco da frente do focinho até o chão. Ele acompanhará deitando. Diga “Deita”, elogie e recompense quando o corpo encostar no chão.",
  },
  {
    nome: "Dá a pata",
    passos:
      "Com o cão sentado, toque levemente a pata dele e diga “Dá a pata”. Quando ele levantar a pata, segure com carinho, elogie e dê o petisco.",
  },
]

const principios = [
  "Sessões curtas de 5 a 10 minutos, várias vezes ao dia.",
  "Use reforço positivo: petiscos, carinho e voz alegre.",
  "Nunca use castigo físico ou gritos — gera medo, não aprendizado.",
  "Seja consistente: use sempre a mesma palavra para cada comando.",
]

export function Comandos() {
  return (
    <section id="comandos" className="py-16 md:py-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-sm font-bold uppercase tracking-wide text-primary">
            Treinamento
          </span>
          <h2 className="mt-2 text-balance font-heading text-3xl font-extrabold text-foreground md:text-4xl">
            Como ensinar comandos ao seu cachorro
          </h2>
          <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
            Com paciência e recompensas, qualquer cão aprende. Veja o passo a
            passo dos comandos essenciais.
          </p>
        </div>

        <div className="mt-12 grid items-start gap-10 lg:grid-cols-2">
          <div className="overflow-hidden rounded-[2rem] border-4 border-card shadow-lg">
            <Image
              src="/images/cachorro-treino.png"
              alt="Pessoa treinando um cachorro border collie atento no parque"
              width={640}
              height={640}
              className="h-full w-full object-cover"
            />
          </div>

          <Accordion type="single" collapsible defaultValue="Senta" className="w-full">
            {comandos.map((comando) => (
              <AccordionItem
                key={comando.nome}
                value={comando.nome}
                className="mb-3 rounded-2xl border border-border bg-card px-5"
              >
                <AccordionTrigger className="font-heading text-lg font-bold text-foreground hover:no-underline">
                  {comando.nome}
                </AccordionTrigger>
                <AccordionContent className="text-base leading-relaxed text-muted-foreground">
                  {comando.passos}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="mt-12 rounded-3xl bg-accent/30 p-6 md:p-10">
          <h3 className="font-heading text-xl font-bold text-foreground">
            Princípios de ouro do treinamento
          </h3>
          <ul className="mt-5 grid gap-4 sm:grid-cols-2">
            {principios.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <span className="mt-1 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                  ✓
                </span>
                <span className="leading-relaxed text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
